package com.senai.reservei.model;

public enum StatusReservaEnum {
    ATIVA,
    CANCELADA,
    CONCLUIDA
}
