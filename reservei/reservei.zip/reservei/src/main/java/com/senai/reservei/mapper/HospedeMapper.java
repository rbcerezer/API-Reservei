package com.senai.reservei.mapper;

import com.senai.reservei.dto.HospedeCreateDTO;
import com.senai.reservei.model.Hospede;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class HospedeMapper {
    public Hospede toModel(HospedeCreateDTO hospedeCreateDTO){
        Hospede hospede = new Hospede();
        hospede.setNome(hospedeCreateDTO.getNome());
        hospede.setDocumento(hospedeCreateDTO.getDocumento());
        hospede.setTelefone(hospedeCreateDTO.getTelefone());
        hospede.setEmail(hospedeCreateDTO.getEmail());
        return hospede;
    }

    public HospedeCreateDTO toDTO(Hospede hospede) {
        HospedeCreateDTO hospedeCreateDTO = new HospedeCreateDTO();
        hospedeCreateDTO.setNome((hospede.getNome()));
        hospedeCreateDTO.setDocumento((hospede.getDocumento()));
        hospedeCreateDTO.setTelefone((hospede.getTelefone()));
        hospedeCreateDTO.setEmail((hospede.getEmail()));
        return hospedeCreateDTO;
    }

    public List<HospedeCreateDTO> toListDTO(List<Hospede> hospedes) {
        List<HospedeCreateDTO> hospedesDTO = new ArrayList<>();
        for(Hospede hospede: hospedes) {
            HospedeCreateDTO hospedeCreateDTO = new HospedeCreateDTO();
            hospedeCreateDTO.setNome((hospede.getNome()));
            hospedeCreateDTO.setDocumento((hospede.getDocumento()));
            hospedeCreateDTO.setTelefone((hospede.getTelefone()));
            hospedeCreateDTO.setEmail((hospede.getEmail()));
            hospedesDTO.add(hospedeCreateDTO);
        }
        return hospedesDTO;
    }

    public void copyProperties(HospedeCreateDTO hospedeDto, Hospede hospede) {
        if (hospedeDto.getNome() != null && !hospedeDto.getNome().trim().isEmpty()) {
            hospede.setNome(hospedeDto.getNome());
        }

        if (hospedeDto.getDocumento() != null && !hospedeDto.getDocumento().trim().isEmpty()) {
            hospede.setDocumento(hospedeDto.getDocumento());
        }

        if (hospedeDto.getTelefone() != null && !hospedeDto.getTelefone().trim().isEmpty()) {
            hospede.setTelefone(hospedeDto.getTelefone());
        }

        if (hospedeDto.getEmail() != null && !hospedeDto.getEmail().trim().isEmpty()) {
            hospede.setEmail(hospedeDto.getEmail());
        }
    }
}
