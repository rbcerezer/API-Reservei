package com.senai.reservei.model;

public enum TipoQuartoEnum {
    SIMPLES,
    DUPLO,
    SUITE
}
