package com.senai.reservei.model;

public enum StatusQuartoEnum {
    DISPONIVEL,
    OCUPADO,
    MANUTENCAO
}
